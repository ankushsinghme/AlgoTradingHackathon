import React, { Fragment } from "react";
import CompanyPage from "./components/CompanyPage";

function App() {
  return (
    <Fragment>
      <CompanyPage />
    </Fragment>
  );
}

export default App;
